
INSERT INTO Zaposleni(Ime, Prezime, JMBG, ZiroRacun, 
Email, BrojTelefona, ProsecnaOcena, BrojZaduzeneOpreme, IsplaceniIznos,
IDMagacin, Pol)
VALUES ('Djordje', 'Zivanovic', '11111111111', '34342432', 
'djordjezivanovic@car.com', '555-333', 10, 0, 0, NULL, 'M')



DELETE FROM Zaposleni
